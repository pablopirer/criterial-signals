# License and Disclaimer (V2.1)

## License
- Licensed for single-firm internal use.
- No resale, redistribution, republication, or third-party sharing without written permission.

## Informational-Use Disclaimer
- This material is for informational purposes only.
- It does not constitute investment, legal, tax, accounting, or financial advice.
- Analysis is based on publicly available information plus explicitly stated assumptions.

## Limitation of Liability
- To the maximum extent permitted by applicable law, Criterial Signals disclaims liability for any direct, indirect, incidental, consequential, or special damages arising from use of this material.
- Users are solely responsible for independent diligence and final decision-making.

## Accuracy and Completeness
- No guarantee is made regarding accuracy, completeness, timeliness, or fitness for a particular purpose.

## Refund Policy Alignment
- Refund eligibility is governed by the published refund policy in the checkout flow.
- Current intended baseline: 7-day refund window for materially misdescribed or inaccessible digital product files, subject to final founder/legal approval.

## Governing Law (Not Public-Ready Placeholder)
- `[Founder/legal review required before public use: governing law and dispute venue to be inserted here.]`
- This file is not final for external use until the above bracketed clause is resolved.
